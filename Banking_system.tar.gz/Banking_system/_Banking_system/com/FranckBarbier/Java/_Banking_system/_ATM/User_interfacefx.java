/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.FranckBarbier.Java._Banking_system._ATM;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author koivogui
 */
public class User_interfacefx extends Application {
    
     
   @Override  public void start(Stage primaryStage) throws IOException, Exception {
       
       FXMLLoader loader = new FXMLLoader(getClass().getResource("FXML.fxml"));    
        Parent root = (Parent) loader.load();
         Scene newScene = new Scene(root);
         Stage newStage = new Stage();
         newStage.setScene(newScene);
         newStage.show();
        try {
                    
            FXMLController user_interface =loader.getController();
            ATM atm = new ATM("0000000001");
            user_interface.add_atm(atm);
            atm.add_user_interface(user_interface);
            atm.start(20000);
         
      } catch (Exception e) {
         e.printStackTrace();
      }
        
        
     /*   
        Parent root = null;
        
            Scene scene = new Scene(root, 800, 600);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Banque Koivogui");
            primaryStage.show();      
        try {
      // Localisation du fichier FXML.
           FXMLController user_interface =lod.getController();
            ATM atm = new ATM("0000000001");
            user_interface.add_atm(atm);
            atm.add_user_interface(user_interface);
            atm.start(20000);
          
    
      
    } catch (IOException ex) {
      System.err.println("Erreur au chargement: " + ex);
    }
     
*/
        
  }

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
                   
         launch(args);
            
    }   
    
}
