/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.FranckBarbier.Java._Banking_system._ATM;

import com.FranckBarbier.Java._Banking_system._Consortium.Account;
import com.FranckBarbier.Java._Banking_system._Consortium.Client;
import com.FranckBarbier.Java._Banking_system._Consortium.Logical_card;
import com.FranckBarbier.Java._Banking_system._Consortium.Plastic_card;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author koivogui
 */
public class FXMLController implements Initializable {

    @FXML  private TextArea _display_area;

    @FXML private TextArea _dispay_are;
    
    @FXML private Button _abort;
    @FXML private Button _continuation;
    @FXML private Button _termination;
    @FXML private Button _enter;
    
    @FXML private Button _key_0;
    @FXML  private Button _key_1;
    @FXML private Button _key_2;
    @FXML private Button _key_3;
    @FXML private Button _key_4;
    @FXML private Button _key_5;
    @FXML  private Button _key_6;
    @FXML private Button _key_7;
    @FXML private Button _key_8;
    @FXML private Button _key_9;
    
    @FXML private Button _dot;
    @FXML private Button _backspace;
   
     
     @FXML private Button _card_inserted;
     @FXML private Button _card_taken;
     
     
     @FXML private Label _cash_dispenser_text;
    @FXML  private TextField _cash_dispenser;
    @FXML private Label _deposit_drawer_text;
    @FXML private TextField _deposit_drawer;
     @FXML private Label _receipt_printer_text;
     @FXML private TextField _receipt_printer;
     
     @FXML protected static final byte _Amount_length = 4;
     @FXML protected static final byte _Password_length = 4;
     @FXML public final static byte Franck_Barbier = 0;
     @FXML public final static byte Oscar_Barbier__Darnal = 1;
     @FXML public final static byte Lena_Barbier__Darnal = 2;
     @FXML public final static byte Joseph_Barbier__Darnal = 3;
      @FXML protected static final Plastic_card[] _Plastic_cards = new Plastic_card[4];

    static {
        _Plastic_cards[Franck_Barbier] = new Plastic_card("PC1 FB", new Logical_card("LC FB", new Client("B1", "11-01-1963"), "1101", 3000));
        _Plastic_cards[Oscar_Barbier__Darnal] = new Plastic_card("PC1 OBD", new Logical_card("LC OBD", new Client("B1", "06-12-1993"), "0612", 1000));
        _Plastic_cards[Lena_Barbier__Darnal] = new Plastic_card("PC1 LBD", new Logical_card("LC LBD", new Client("B2", "15-04-1996"), "1504", 500));
        _Plastic_cards[Joseph_Barbier__Darnal] = new Plastic_card("PC1 JDB", new Logical_card("LC JBD", new Client("B1", "22-02-2001"), "2202", 100));
    }
    protected StringBuffer _amount = new StringBuffer(_Amount_length);
    protected StringBuffer _password = new StringBuffer(_Password_length);
    protected ATM _atm;

    public void add_atm(ATM atm) {
        _atm = atm;
    }


   @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
       // App.setController(this);
    }    
    
     @FXML
     private void card_inserted(ActionEvent evt) {
        _card_inserted.setDisable(true);
        try {
           _atm.card_reader().card_inserted(_Plastic_cards[Franck_Barbier]);
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage() + "\n\n");
            // _atm.card_reader().breakdown();
        }
    }
      @FXML
    private void card_taken(ActionEvent evt) {
        _card_taken.setDisable(true);
        try {
            _atm.card_reader().card_taken();
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
            // _atm.card_reader().breakdown();
        }
    }
    
     @FXML
    private void abort(ActionEvent evt) {
        try {
            _atm.abort();
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
    }
         @FXML
    private void continuation(ActionEvent evt) {
        try {
            _atm.continuation();
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
    }
     @FXML
    private void enter(ActionEvent evt) {
        try {
            try {
                if (_atm.amount_choice()) {
                    _atm.amount_chosen((new Integer(_amount.toString())).intValue());
                }
            } catch (NumberFormatException nfe) {
            }
            if (_atm.password_request()) {
                _atm.password_entered(_password.toString());
            }
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
    }
     @FXML
    private void termination(ActionEvent evt) {
        try {
            _atm.termination();
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
    }
     @FXML
    private void on_backspace(ActionEvent evt) {
        if (_atm.amount_choice()) {
            if (_amount.length() > 0) {
                _amount.deleteCharAt(_amount.length() - 1);
                StringBuffer screen = new StringBuffer(_display_area.getText());
                if (screen.length() > 0) {
                    screen.deleteCharAt(screen.length() - 1);
                }
                _display_area.setText(screen.toString());
            }
        }
        if (_atm.password_request()) {
            if (_password.length() > 0) {
                _password.deleteCharAt(_password.length() - 1);
                StringBuffer screen = new StringBuffer(_display_area.getText());
                if (screen.length() > 0) {
                    screen.deleteCharAt(screen.length() - 1);
                }
                _display_area.setText(screen.toString());
            }
        }
    }
     @FXML
    private void on_key_0(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[0]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('0');
                _display_area.setText(_display_area.getText() + '0');
            }
        }
        try {
            if (_atm.operation_kind_choice()) {
                _atm.operation_kind_chosen(Operation._Kinds[0]);
            }
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('0');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
    }
     @FXML
    private void on_key_9(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[9]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('9');
                _display_area.setText(_display_area.getText() + '9');
            }
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('9');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
    }
     @FXML
    private void on_key_8(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[8]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('8');
                _display_area.setText(_display_area.getText() + '8');
            }
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('8');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
    }
     @FXML
    private void on_key_7(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[7]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('7');
                _display_area.setText(_display_area.getText() + '7');
            }
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('7');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
    }
     @FXML
    private void on_key_6(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[6]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('6');
                _display_area.setText(_display_area.getText() + '6');
            }
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('6');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
    }
     @FXML
    private void on_key_5(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[5]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('5');
                _display_area.setText(_display_area.getText() + '5');
            }
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('5');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
    }
     @FXML
    private void on_key_4(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[4]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('4');
                _display_area.setText(_display_area.getText() + '4');
            }
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('4');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
    }
     @FXML
    private void on_key_3(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[3]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('3');
                _display_area.setText(_display_area.getText() + '3');
            }
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('3');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
        try {
            if (_atm.operation_kind_choice()) {
                _atm.operation_kind_chosen(Operation._Kinds[3]);
            }
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
    }
    @FXML
    private void on_key_2(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[2]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('2');
                _display_area.setText(_display_area.getText() + '2');
            }
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('2');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
        try {
            if (_atm.operation_kind_choice()) {
                _atm.operation_kind_chosen(Operation._Kinds[2]);
            }
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
    }
     @FXML
    private void on_key_1(ActionEvent evt) {
        try {
            if (_atm.account_choice()) {
                _atm.account_chosen((Account) _atm._portfolio.account().toArray()[1]);
            }
        } catch (ArrayIndexOutOfBoundsException aioobe) {
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.amount_choice()) {
            if (_amount.length() < _Amount_length) {
                _amount.append('1');
                _display_area.setText(_display_area.getText() + '1');
            }
        }
        try {
            if (_atm.operation_kind_choice()) {
                _atm.operation_kind_chosen(Operation._Kinds[1]);
            }
        } catch (com.pauware.pauware_engine._Exception.Statechart_exception se) {
            _display_area.setText(se.getMessage());
        }
        if (_atm.password_request()) {
            if (_password.length() < _Password_length) {
                _password.append('1');
                _display_area.setText(_display_area.getText() + "*");
            }
        }
    }
     @FXML
    private void exitForm(java.awt.event.WindowEvent evt) {
        try {
            _atm.stop();
        } catch (Throwable t) {
            t.printStackTrace();
        }
        System.exit(0);
    }
     @FXML
    public void activate_cash_dispenser() {
        _cash_dispenser.setText("du fric !");
        try {
            Thread.sleep(2000L);
        } catch (InterruptedException ie) {
            _display_area.setText(ie.getMessage());
        }
        _cash_dispenser.setText("no more money...");
    }
        @FXML
    public void activate_deposit_drawer() {
        _deposit_drawer.setStyle("");
        try {
            Thread.sleep(2000L);
        } catch (InterruptedException ie) {
            _display_area.setText(ie.getMessage());
        }
        _deposit_drawer.setStyle("");
    }
     @FXML
    public void activate_receipt_printer() {
       // _receipt_printer.setBackground(java.awt.Color.RED);
        try {
            Thread.sleep(2000L);
        } catch (InterruptedException ie) {
            _display_area.setText(ie.getMessage());
        }
        //_receipt_printer.setBackground(java.awt.Color.BLACK);
    }
     @FXML
    public void display_account() {
        switch (_atm._operation_kind) {
            case Operation.Deposit:
                _display_area.setText("Deposit(" + _atm._account.unique() + "):\n" + _atm._amount);
                break;
            case Operation.Query:
                _display_area.setText("Query(" + _atm._account.unique() + "):\n" + _atm._account.balance());
                break;
            case Operation.Transfer:
                _display_area.setText("Transfer(" + _atm._account.unique() + "\n->" + _atm._transfer_account.unique() + "): " + _atm._amount);
                break;
            case Operation.Withdrawal:
                _display_area.setText("Withdrawal(" + _atm._account.unique() + "):\n" + _atm._amount);
                break;
        }
    }
     @FXML
    public void display_card_put_down() {
        _display_area.setText("card put down\n");
        _card_taken.setDisable(true);
        try {
            Thread.sleep(2000L);
        } catch (InterruptedException ie) {
            _display_area.setText(ie.getMessage());
        }
    }
    
    
     @FXML
     public void display_card_unreadable() {
        _display_area.setText("card unreadable\n");
    }
    
     @FXML
    public void display_choose_account() {
        _display_area.setText("choose account (" + Operation._Literals[_atm._operation_kind] + ")\n");
        for (int i = 0; i < _atm._portfolio.account().toArray().length; i++) {
            _display_area.setText(_display_area.getText() + i + ".: " + ((Account) _atm._portfolio.account().toArray()[i]).unique() + "\n");
        }
    }
     @FXML
    public void display_choose_amount() {
        _display_area.setText("choose amount\n");
        _amount.delete(0, _Amount_length);
    }
     @FXML
    public void display_choose_continuation_or_termination() {
        _display_area.setText("choose continuation or termination\n");
    }
     @FXML
    public void display_choose_operation_kind() {
        _display_area.setText("choose operation kind\n");
        for (int i = 0; i < Operation._Literals.length; i++) {
            _display_area.setText(_display_area.getText() + i + ".: " + Operation._Literals[i] + "\n");
        }
    }
 @FXML
    public void display_enter_password() {
        _display_area.setText("enter password\n");
        _password.delete(0, _Password_length);
    }
 @FXML
    public void display_insert_card() {
        
        _display_area.setText("insert card\n");
        _card_inserted.setDisable(false);
        
    }
 @FXML
    public void display_invalid_password() {
        _display_area.setText("invalid password\n");
    }
 @FXML
    public void display_operation_error(String text) {
        _display_area.setText("operation error: " + text + "\n");
    }
 @FXML
    public void display_operation_starts_() {
        _display_area.setText("operation starts...\n");
    }
 @FXML
    public void display_out_of_order() {
        _display_area.setText("out of order\n");
    }
 @FXML
    public void display_take_card() {
        _display_area.setText("take card\n");
        _card_taken.setDisable(false);
    }
 @FXML
    public void display_transaction_error(String text) {
        _display_area.setText("transaction error: " + text + "\n");
    }
 @FXML
    public void display_transaction_starts_() {
        _display_area.setText("transaction starts...\n");
    }

    
}
    
